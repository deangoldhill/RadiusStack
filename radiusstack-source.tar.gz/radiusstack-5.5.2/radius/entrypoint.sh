#!/bin/sh
set -eu
mkdir -p /certs_shared
if [ ! -f /certs_shared/server.pem ]; then
    echo "Generating default 10-year CA and EAP certificates..."
    openssl req -new -newkey rsa:2048 -days 3650 -nodes -x509         -keyout /certs_shared/ca.key -out /certs_shared/ca.pem         -subj "/C=US/ST=State/L=City/O=RadiusCA/CN=RadiusCA"

    openssl req -new -newkey rsa:2048 -nodes         -keyout /certs_shared/server.key -out /certs_shared/server.csr         -subj "/C=US/ST=State/L=City/O=Radius/CN=RadiusServer"

    openssl x509 -req -days 3650 -in /certs_shared/server.csr         -CA /certs_shared/ca.pem -CAkey /certs_shared/ca.key -CAcreateserial         -out /certs_shared/server.pem

    rm -f /certs_shared/server.csr /certs_shared/ca.srl
fi

chmod 644 /certs_shared/ca.key /certs_shared/ca.pem /certs_shared/server.key /certs_shared/server.pem

DB_HOST="${DB_HOST:-mariadb}"
DB_USER="${DB_USER:-radius}"
DB_PASS="${DB_PASSWORD:-}"
DB_NAME="${DB_NAME:-radius}"

DB_DEFAULTS=/run/radiusstack-radsec-db.cnf
umask 077
printf "[client]\nhost=%s\nuser=%s\npassword=%s\ndatabase=%s\n" "$DB_HOST" "$DB_USER" "$DB_PASS" "$DB_NAME" > "$DB_DEFAULTS"
chmod 0600 "$DB_DEFAULTS"

echo "Waiting for MariaDB at ${DB_HOST}..."
until mysql --skip-ssl -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASS}" -D "${DB_NAME}" -e "SELECT 1" >/dev/null 2>&1; do
    sleep 2
done

/usr/local/sbin/generate-vsa-dictionary
/usr/local/sbin/generate-radsec-listener

DEBUG_MODE=$(mysql --skip-ssl -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASS}" -D "${DB_NAME}" -N -B \
    -e "SELECT setting_value FROM settings WHERE setting_key='radius_debug';" 2>/dev/null)

if command -v radiusd >/dev/null 2>&1; then
    RAD_CMD="radiusd"
elif [ -x "/opt/sbin/radiusd" ]; then
    RAD_CMD="/opt/sbin/radiusd"
elif [ -x "/opt/bin/radiusd" ]; then
    RAD_CMD="/opt/bin/radiusd"
elif [ -x "/usr/sbin/radiusd" ]; then
    RAD_CMD="/usr/sbin/radiusd"
elif [ -x "/usr/local/sbin/radiusd" ]; then
    RAD_CMD="/usr/local/sbin/radiusd"
else
    echo "Searching for radiusd..."
    RAD_CMD=$(find / -type f -name radiusd -executable 2>/dev/null | head -n 1)
fi

if [ -z "$RAD_CMD" ]; then
    echo "FATAL ERROR: radiusd executable not found anywhere on the system!"
    exit 1
fi

if [ "$DEBUG_MODE" = "true" ]; then
    echo "Starting FreeRADIUS ($RAD_CMD) with threaded foreground logging; RadSec TLS requires worker threads..."
else
    echo "Starting FreeRADIUS ($RAD_CMD) in normal threaded foreground mode..."
fi
exec "$RAD_CMD" -fxx -l stdout
